var speed = 1; // Choose between 1 and 3
var particles = 1; // Choose between 1 and 3
var lines = false; 
var opacity = 0.5; // Chose between 0 and 1
var color = "#FFFFFF"; // Choose a hex color, Example: Yellow = "#f4ce42"
