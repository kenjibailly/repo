var size = 75; // Choose between 100% 90% 80% 75%
