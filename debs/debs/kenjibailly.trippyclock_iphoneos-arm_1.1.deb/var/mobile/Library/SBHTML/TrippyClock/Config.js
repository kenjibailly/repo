var size = 50; // Choose between 100% 90% 80% 75% 50%
