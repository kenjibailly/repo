function init() {
  // For testing
  // var bg = true;
  // var size = 3;
  var solarsystem = document.getElementsByClassName('solarsystem')[0];
  solarsystem.style.webkitTransform = "scale(0."+size+")";
}
init();
